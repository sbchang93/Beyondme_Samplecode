package com.yudong80.reactivejava.chapter05;

public class SubscribeOnExample {

	public static void main(String[] args) { 
		SubscribeOnExample demo = new SubscribeOnExample();
		
	}
}
