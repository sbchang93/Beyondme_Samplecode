package com.yudong80.reactivejava.common;

/**
 * Marker Interface for Marble Diagram Explained
 */
public interface MarbleDiagram {
	public void marbleDiagram();
}
