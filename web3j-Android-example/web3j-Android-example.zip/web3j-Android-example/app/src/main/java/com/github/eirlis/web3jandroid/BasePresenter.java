package com.github.eirlis.web3jandroid;

/**
 * Created by eirlis on 29.06.17.
 */

public interface BasePresenter {

    void start();
}
