package com.github.eirlis.web3jandroid;

/**
 * Created by eirlis on 29.06.17.
 */

public interface BaseView<T> {

    void setPresenter(T presenter);
}
