package com.github.eirlis.web3jandroid.wallet;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

import com.github.eirlis.web3jandroid.R;

import org.web3j.protocol.Web3j;
import org.web3j.protocol.Web3jFactory;
import org.web3j.protocol.core.methods.response.Web3ClientVersion;
import org.web3j.protocol.http.HttpService;

import java.io.IOException;

/**
 * Created by eirlis on 29.06.17.
 */

public class WalletActivity extends AppCompatActivity {

    public static final String TAG = WalletActivity.class.getName();

    private TextView mWalletAddress;

    private TextView mBalance;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallet);

        //Web3j web3 = Web3jFactory.build(new HttpService());
        //Web3j web3 = Web3jFactory.build(new HttpService("http://localhost:8545"));
        //Web3j web3 = Web3jFactory.build(new HttpService("http://127.0.0.1:8545"));
        Web3j web3 = Web3jFactory.build(new HttpService("http://10.244.179.60:8545"));

        Log.e("test","Web3jFactory - clientVersion : ");
        try {
            Web3ClientVersion web3ClientVersion = web3.web3ClientVersion().send();
            String clientVersion = web3ClientVersion.getWeb3ClientVersion();
            Log.e("test","clientVersion : "+ clientVersion) ;
        }catch(IOException e){
            Log.e("test","clientVersion Error !!! ") ;
        }

        //web3j = Web3j.build(new HttpService());
        //Web3j web3j = Web3j.build(new HttpService());
        //Web3j.build(new HttpService());
        //Web3j.build(new HttpService("http://localhost:8545"));


//        Web3j web3 = Web3j.build(new HttpService("http://127.0.0.1:8080"));
//        Web3j web3 = Web3j.build(new HttpService());  // defaults to http://localhost:8545/
//        Web3ClientVersion web3ClientVersion = web3.web3ClientVersion().sendAsync().get();
//        String clientVersion = web3ClientVersion.getWeb3ClientVersion();

//        Web3j web3 = Web3jFactory.build(new HttpService());  // defaults to http://localhost:8545/
//...

        mWalletAddress = (TextView) findViewById(R.id.account_address);
        mBalance = (TextView) findViewById(R.id.wallet_balance);

        Bundle extras = getIntent().getExtras();
        mWalletAddress.setText(extras.getString("WalletAddress")); // 생성되어서 받아온 계좌 번호
    }
}

