package com.github.eirlis.web3jandroid.wallet;

/**
 * Created by eirlis on 29.06.17.
 */

public class WalletPresenter {
}
